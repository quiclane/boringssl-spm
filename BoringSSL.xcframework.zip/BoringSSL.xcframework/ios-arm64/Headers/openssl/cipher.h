// Copyright 1995-2016 The OpenSSL Project Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef OPENSSL_HEADER_CIPHER_H
#define OPENSSL_HEADER_CIPHER_H

#include <openssl/base.h>   // IWYU pragma: export

#if defined(__cplusplus)
extern "C" {
#endif


// Ciphers.


// Cipher primitives.
//
// The following functions return |EVP_CIPHER| objects that implement the named
// cipher algorithm.

OPENSSL_EXPORT const EVP_CIPHER *EVP_rc4(void);

OPENSSL_EXPORT const EVP_CIPHER *EVP_des_cbc(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_des_ecb(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_des_ede(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_des_ede3(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_des_ede_cbc(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_des_ede3_cbc(void);

OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_128_ecb(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_128_cbc(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_128_ctr(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_128_ofb(void);

OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_256_ecb(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_256_cbc(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_256_ctr(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_256_ofb(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_256_xts(void);

// EVP_enc_null returns a 'cipher' that passes plaintext through as
// ciphertext.
OPENSSL_EXPORT const EVP_CIPHER *EVP_enc_null(void);

// EVP_rc2_cbc returns a cipher that implements 128-bit RC2 in CBC mode.
OPENSSL_EXPORT const EVP_CIPHER *EVP_rc2_cbc(void);

// EVP_rc2_40_cbc returns a cipher that implements 40-bit RC2 in CBC mode. This
// is obviously very, very weak and is included only in order to read PKCS#12
// files, which often encrypt the certificate chain using this cipher. It is
// deliberately not exported.
const EVP_CIPHER *EVP_rc2_40_cbc(void);

// EVP_get_cipherbynid returns the cipher corresponding to the given NID, or
// NULL if no such cipher is known. Note using this function links almost every
// cipher implemented by BoringSSL into the binary, whether the caller uses them
// or not. Size-conscious callers, such as client software, should not use this
// function.
OPENSSL_EXPORT const EVP_CIPHER *EVP_get_cipherbynid(int nid);


// Cipher context allocation.
//
// An |EVP_CIPHER_CTX| represents the state of an encryption or decryption in
// progress.

// EVP_CIPHER_CTX_init initialises an, already allocated, |EVP_CIPHER_CTX|.
OPENSSL_EXPORT void EVP_CIPHER_CTX_init(EVP_CIPHER_CTX *ctx);

// EVP_CIPHER_CTX_new allocates a fresh |EVP_CIPHER_CTX|, calls
// |EVP_CIPHER_CTX_init| and returns it, or NULL on allocation failure.
OPENSSL_EXPORT EVP_CIPHER_CTX *EVP_CIPHER_CTX_new(void);

// EVP_CIPHER_CTX_cleanup frees any memory referenced by |ctx|. It returns
// one.
OPENSSL_EXPORT int EVP_CIPHER_CTX_cleanup(EVP_CIPHER_CTX *ctx);

// EVP_CIPHER_CTX_free calls |EVP_CIPHER_CTX_cleanup| on |ctx| and then frees
// |ctx| itself.
OPENSSL_EXPORT void EVP_CIPHER_CTX_free(EVP_CIPHER_CTX *ctx);

// EVP_CIPHER_CTX_copy sets |out| to be a duplicate of the current state of
// |in|. The |out| argument must have been previously initialised.
OPENSSL_EXPORT int EVP_CIPHER_CTX_copy(EVP_CIPHER_CTX *out,
                                       const EVP_CIPHER_CTX *in);

// EVP_CIPHER_CTX_reset calls |EVP_CIPHER_CTX_cleanup| followed by
// |EVP_CIPHER_CTX_init| and returns one.
OPENSSL_EXPORT int EVP_CIPHER_CTX_reset(EVP_CIPHER_CTX *ctx);


// Cipher context configuration.

// EVP_CipherInit_ex configures |ctx| for a fresh encryption (or decryption, if
// |enc| is zero) operation using |cipher|. If |ctx| has been previously
// configured with a cipher then |cipher|, |key| and |iv| may be |NULL| and
// |enc| may be -1 to reuse the previous values. The operation will use |key|
// as the key and |iv| as the IV (if any). These should have the correct
// lengths given by |EVP_CIPHER_key_length| and |EVP_CIPHER_iv_length|. It
// returns one on success and zero on error.
OPENSSL_EXPORT int EVP_CipherInit_ex(EVP_CIPHER_CTX *ctx,
                                     const EVP_CIPHER *cipher, ENGINE *engine,
                                     const uint8_t *key, const uint8_t *iv,
                                     int enc);

// EVP_EncryptInit_ex calls |EVP_CipherInit_ex| with |enc| equal to one.
OPENSSL_EXPORT int EVP_EncryptInit_ex(EVP_CIPHER_CTX *ctx,
                                      const EVP_CIPHER *cipher, ENGINE *impl,
                                      const uint8_t *key, const uint8_t *iv);

// EVP_DecryptInit_ex calls |EVP_CipherInit_ex| with |enc| equal to zero.
OPENSSL_EXPORT int EVP_DecryptInit_ex(EVP_CIPHER_CTX *ctx,
                                      const EVP_CIPHER *cipher, ENGINE *impl,
                                      const uint8_t *key, const uint8_t *iv);


// Cipher operations.

// EVP_EncryptUpdate_ex encrypts |in_len| bytes from |in| and writes up to
// |max_out| bytes of ciphertext to |out|. On success, it sets |*out_len| to
// the number of output bytes and returns one. Otherwise, it returns zero.
//
// If |max_out| is not large enough for the output, the function will return
// zero. The size of output buffer needed depends on the cipher and the number
// of bytes encrypted by |ctx| thus far.
//
// In ciphers whose block size is not 1, such as CBC, individual calls to
// |EVP_EncryptUpdate_ex| may output more or less than |in_len| bytes: a single
// call to |EVP_EncryptUpdate_ex| may output at most |in_len + block_size - 1|
// bytes. Additionally, the total output across all |EVP_EncryptUpdate_ex| and
// |EVP_EncryptFinal_ex2| calls will be at most the total input plus one byte,
// rounded up to a multiple of the block size.
OPENSSL_EXPORT int EVP_EncryptUpdate_ex(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                        size_t *out_len, size_t max_out_len,
                                        const uint8_t *in, size_t in_len);

// EVP_EncryptFinal_ex2 finishes an encryption operation and writes up to
// |max_out| bytes of output to out. On success, it sets |*out_len| to the
// number of bytes written and returns one. Otherwise, it returns zero.
//
// If |max_out| is not large enough for the output, the function will return
// zero. The size of output buffer needed depends on the cipher and the number
// of bytes encrypted.
//
// If the block size is 1, there will be no final output at all; otherwise, at
// most one block of ciphertext will be written to the output.
//
// If padding is enabled (the default) and the block size is not 1, then
// standard padding is applied to create the final block. If padding is
// disabled (with |EVP_CIPHER_CTX_set_padding|) then any partial block
// remaining will cause an error. The function returns one on success and zero
// otherwise.
OPENSSL_EXPORT int EVP_EncryptFinal_ex2(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                        size_t *out_len, size_t max_out_len);

// EVP_DecryptUpdate_ex decrypts |in_len| bytes from |in| and writes up to
// |max_out| bytes of plaintext to |out|. On success, it sets |*out_len| to
// the number of output bytes and returns one. Otherwise, it returns zero.
//
// If |max_out| is not large enough for the output, the function will return
// zero. The size of output buffer needed depends on the cipher and the number
// of bytes decrypted by |ctx| thus far.
//
// In ciphers whose block size is not 1, such as CBC, individual calls to
// |EVP_DecryptUpdate_ex| may output more or less than |in_len| bytes: a single
// call to |EVP_DecryptUpdate_ex| may output at most |in_len + block_size - 1|
// bytes. Additionally, the total output across all |EVP_DecryptUpdate_ex| and
// |EVP_DecryptFinal_ex2| calls will be at most the total input.
//
// WARNING: if the cipher is an AEAD cipher, decrypted data should not be
// parsed or otherwise processed until success has been returned by
// |EVP_EncryptFinal_ex2|.
OPENSSL_EXPORT int EVP_DecryptUpdate_ex(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                        size_t *out_len, size_t max_out_len,
                                        const uint8_t *in, size_t in_len);

// EVP_DecryptFinal_ex2 finishes a decryption operation and writes up to
// |max_out| bytes of output to out. On success, it sets |*out_len| to the
// number of bytes written and returns one. Otherwise, it returns zero.
//
// If |max_out| is not large enough for the output, the function will return
// zero. The size of output buffer needed depends on the cipher and the number
// of bytes decrypted.
//
// If the block size is 1, there will be no final output at all; otherwise, at
// most one block of ciphertext will be written to the output.
//
// If padding is enabled (the default) and the block size is not 1, then
// standard padding is removed from the final block.
//
// WARNING: it is unsafe to call this function after decrypting unauthenticated
// ciphertext if padding is enabled and the block size is not 1 ("padding
// oracle").
OPENSSL_EXPORT int EVP_DecryptFinal_ex2(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                        size_t *out_len, size_t max_out_len);

// EVP_CipherUpdate_ex calls either |EVP_EncryptUpdate_ex| or
// |EVP_DecryptUpdate_ex| depending on how |ctx| has been setup.
OPENSSL_EXPORT int EVP_CipherUpdate_ex(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                       size_t *out_len, size_t max_out_len,
                                       const uint8_t *in, size_t in_len);

// EVP_CipherUpdateAAD adds |in_len| bytes from |in| to the AAD. The AAD must
// be fully specified in this way before any plaintext or ciphertext is
// supplied to the other functions. Please consider moving to the |EVP_AEAD|
// APIs instead.
OPENSSL_EXPORT int EVP_CipherUpdateAAD(EVP_CIPHER_CTX *ctx, const uint8_t *in,
                                       size_t in_len);

// EVP_CipherFinal_ex2 calls either |EVP_EncryptFinal_ex2| or
// |EVP_DecryptFinal_ex2| depending on how |ctx| has been setup.
OPENSSL_EXPORT int EVP_CipherFinal_ex2(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                       size_t *out_len, size_t max_out_len);


// Cipher context accessors.

// EVP_CIPHER_CTX_cipher returns the |EVP_CIPHER| underlying |ctx|, or NULL if
// none has been set.
OPENSSL_EXPORT const EVP_CIPHER *EVP_CIPHER_CTX_cipher(
    const EVP_CIPHER_CTX *ctx);

// EVP_CIPHER_CTX_nid returns a NID identifying the |EVP_CIPHER| underlying
// |ctx| (e.g. |NID_aes_128_gcm|). It will crash if no cipher has been
// configured.
OPENSSL_EXPORT int EVP_CIPHER_CTX_nid(const EVP_CIPHER_CTX *ctx);

// EVP_CIPHER_CTX_encrypting returns one if |ctx| is configured for encryption
// and zero otherwise.
OPENSSL_EXPORT int EVP_CIPHER_CTX_encrypting(const EVP_CIPHER_CTX *ctx);

// EVP_CIPHER_CTX_block_size returns the block size, in bytes, of the cipher
// underlying |ctx|, or one if the cipher is a stream cipher. It will crash if
// no cipher has been configured.
OPENSSL_EXPORT unsigned EVP_CIPHER_CTX_block_size(const EVP_CIPHER_CTX *ctx);

// EVP_CIPHER_CTX_key_length returns the key size, in bytes, of the cipher
// underlying |ctx| or zero if no cipher has been configured.
OPENSSL_EXPORT unsigned EVP_CIPHER_CTX_key_length(const EVP_CIPHER_CTX *ctx);

// EVP_CIPHER_CTX_iv_length returns the IV size, in bytes, of the cipher
// underlying |ctx|. It will crash if no cipher has been configured.
OPENSSL_EXPORT unsigned EVP_CIPHER_CTX_iv_length(const EVP_CIPHER_CTX *ctx);

// EVP_CIPHER_CTX_get_app_data returns the opaque, application data pointer for
// |ctx|, or NULL if none has been set.
OPENSSL_EXPORT void *EVP_CIPHER_CTX_get_app_data(const EVP_CIPHER_CTX *ctx);

// EVP_CIPHER_CTX_set_app_data sets the opaque, application data pointer for
// |ctx| to |data|.
OPENSSL_EXPORT void EVP_CIPHER_CTX_set_app_data(EVP_CIPHER_CTX *ctx,
                                                void *data);

// EVP_CIPHER_CTX_flags returns a value which is the OR of zero or more
// |EVP_CIPH_*| flags. It will crash if no cipher has been configured.
OPENSSL_EXPORT uint32_t EVP_CIPHER_CTX_flags(const EVP_CIPHER_CTX *ctx);

// EVP_CIPHER_CTX_mode returns one of the |EVP_CIPH_*| cipher mode values
// enumerated below. It will crash if no cipher has been configured.
OPENSSL_EXPORT uint32_t EVP_CIPHER_CTX_mode(const EVP_CIPHER_CTX *ctx);

// EVP_CIPHER_CTX_ctrl is an |ioctl| like function. The |command| argument
// should be one of the |EVP_CTRL_*| values. The |arg| and |ptr| arguments are
// specific to the command in question.
OPENSSL_EXPORT int EVP_CIPHER_CTX_ctrl(EVP_CIPHER_CTX *ctx, int command,
                                       int arg, void *ptr);

// EVP_CIPHER_CTX_set_padding sets whether padding is enabled for |ctx| and
// returns one. Pass a non-zero |pad| to enable padding (the default) or zero
// to disable.
OPENSSL_EXPORT int EVP_CIPHER_CTX_set_padding(EVP_CIPHER_CTX *ctx, int pad);

// EVP_CIPHER_CTX_set_key_length sets the key length for |ctx|. This is only
// valid for ciphers that can take a variable length key. It returns one on
// success and zero on error.
OPENSSL_EXPORT int EVP_CIPHER_CTX_set_key_length(EVP_CIPHER_CTX *ctx,
                                                 unsigned key_len);


// Cipher accessors.

// EVP_CIPHER_nid returns a NID identifying |cipher|. (For example,
// |NID_aes_128_gcm|.)
OPENSSL_EXPORT int EVP_CIPHER_nid(const EVP_CIPHER *cipher);

// EVP_CIPHER_block_size returns the block size, in bytes, for |cipher|, or one
// if |cipher| is a stream cipher.
OPENSSL_EXPORT unsigned EVP_CIPHER_block_size(const EVP_CIPHER *cipher);

// EVP_CIPHER_key_length returns the key size, in bytes, for |cipher|. If
// |cipher| can take a variable key length then this function returns the
// default key length and |EVP_CIPHER_flags| will return a value with
// |EVP_CIPH_VARIABLE_LENGTH| set.
OPENSSL_EXPORT unsigned EVP_CIPHER_key_length(const EVP_CIPHER *cipher);

// EVP_CIPHER_iv_length returns the IV size, in bytes, of |cipher|, or zero if
// |cipher| doesn't take an IV.
OPENSSL_EXPORT unsigned EVP_CIPHER_iv_length(const EVP_CIPHER *cipher);

// EVP_CIPHER_flags returns a value which is the OR of zero or more
// |EVP_CIPH_*| flags.
OPENSSL_EXPORT uint32_t EVP_CIPHER_flags(const EVP_CIPHER *cipher);

// EVP_CIPHER_mode returns one of the cipher mode values enumerated below.
OPENSSL_EXPORT uint32_t EVP_CIPHER_mode(const EVP_CIPHER *cipher);


// Key derivation.

// EVP_BytesToKey generates a key and IV for the cipher |type| by iterating
// |md| |count| times using |data| and an optional |salt|, writing the result to
// |key| and |iv|. If not NULL, the |key| and |iv| buffers must have enough
// space to hold a key and IV for |type|, as returned by |EVP_CIPHER_key_length|
// and |EVP_CIPHER_iv_length|. This function returns the length of the key
// (without the IV) on success or zero on error.
//
// If |salt| is NULL, the empty string is used as the salt. Salt lengths other
// than 0 and 8 are not supported by this function. Either of |key| or |iv| may
// be NULL to skip that output.
//
// When the total data derived is less than the size of |md|, this function
// implements PBKDF1 from RFC 8018. Otherwise, it generalizes PBKDF1 by
// computing prepending the previous output to |data| and re-running PBKDF1 for
// further output.
//
// This function is provided for compatibility with legacy uses of PBKDF1. New
// applications should use a more modern algorithm, such as |EVP_PBE_scrypt|.
OPENSSL_EXPORT int EVP_BytesToKey(const EVP_CIPHER *type, const EVP_MD *md,
                                  const uint8_t salt[8], const uint8_t *data,
                                  size_t data_len, unsigned count, uint8_t *key,
                                  uint8_t *iv);


// Cipher modes (for |EVP_CIPHER_mode|).

#define EVP_CIPH_STREAM_CIPHER 0x0
#define EVP_CIPH_ECB_MODE 0x1
#define EVP_CIPH_CBC_MODE 0x2
#define EVP_CIPH_CFB_MODE 0x3
#define EVP_CIPH_OFB_MODE 0x4
#define EVP_CIPH_CTR_MODE 0x5
#define EVP_CIPH_GCM_MODE 0x6
#define EVP_CIPH_XTS_MODE 0x7

// The following values are never returned from |EVP_CIPHER_mode| and are
// included only to make it easier to compile code with BoringSSL.
#define EVP_CIPH_CCM_MODE 0x8
#define EVP_CIPH_OCB_MODE 0x9
#define EVP_CIPH_WRAP_MODE 0xa


// Cipher flags (for |EVP_CIPHER_flags|).

// EVP_CIPH_VARIABLE_LENGTH indicates that the cipher takes a variable length
// key.
#define EVP_CIPH_VARIABLE_LENGTH 0x40

// EVP_CIPH_ALWAYS_CALL_INIT indicates that the |init| function for the cipher
// should always be called when initialising a new operation, even if the key
// is NULL to indicate that the same key is being used.
#define EVP_CIPH_ALWAYS_CALL_INIT 0x80

// EVP_CIPH_CUSTOM_IV indicates that the cipher manages the IV itself rather
// than keeping it in the |iv| member of |EVP_CIPHER_CTX|.
#define EVP_CIPH_CUSTOM_IV 0x100

// EVP_CIPH_CTRL_INIT indicates that EVP_CTRL_INIT should be used when
// initialising an |EVP_CIPHER_CTX|.
#define EVP_CIPH_CTRL_INIT 0x200

// EVP_CIPH_FLAG_CUSTOM_CIPHER indicates that the cipher manages blocking
// itself. This causes EVP_(En|De)crypt_ex to be simple wrapper functions.
#define EVP_CIPH_FLAG_CUSTOM_CIPHER 0x400

// EVP_CIPH_FLAG_AEAD_CIPHER specifies that the cipher is an AEAD. This is an
// older version of the proper AEAD interface. See aead.h for the current
// one.
#define EVP_CIPH_FLAG_AEAD_CIPHER 0x800

// EVP_CIPH_CUSTOM_COPY indicates that the |ctrl| callback should be called
// with |EVP_CTRL_COPY| at the end of normal |EVP_CIPHER_CTX_copy|
// processing.
#define EVP_CIPH_CUSTOM_COPY 0x1000

// EVP_CIPH_FLAG_NON_FIPS_ALLOW is meaningless. In OpenSSL it permits non-FIPS
// algorithms in FIPS mode. But BoringSSL FIPS mode doesn't prohibit algorithms
// (it's up the the caller to use the FIPS module in a fashion compliant with
// their needs). Thus this exists only to allow code to compile.
#define EVP_CIPH_FLAG_NON_FIPS_ALLOW 0


// Deprecated functions

// EVP_CipherInit acts like EVP_CipherInit_ex except that |EVP_CIPHER_CTX_init|
// is called on |cipher| first, if |cipher| is not NULL.
OPENSSL_EXPORT int EVP_CipherInit(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *cipher,
                                  const uint8_t *key, const uint8_t *iv,
                                  int enc);

// EVP_EncryptInit calls |EVP_CipherInit| with |enc| equal to one.
OPENSSL_EXPORT int EVP_EncryptInit(EVP_CIPHER_CTX *ctx,
                                   const EVP_CIPHER *cipher, const uint8_t *key,
                                   const uint8_t *iv);

// EVP_DecryptInit calls |EVP_CipherInit| with |enc| equal to zero.
OPENSSL_EXPORT int EVP_DecryptInit(EVP_CIPHER_CTX *ctx,
                                   const EVP_CIPHER *cipher, const uint8_t *key,
                                   const uint8_t *iv);

// EVP_CipherUpdate does the same as |EVP_CipherUpdate_ex|, except that no
// output size is given and thus no bounds checking is performed.
//
// Additionally, if |ctx| is an AEAD cipher, e.g. |EVP_aes_128_gcm|, and |out|
// is NULL, this function instead behaves like |EVP_CipherUpdateAAD|.
//
// WARNING: This function does not check bounds on |out|, and correctly sizing
// the output buffer is difficult. Use |EVP_CipherUpdate_ex| or
// |EVP_CipherUpdateAAD| instead.
OPENSSL_EXPORT int EVP_CipherUpdate(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                    int *out_len, const uint8_t *in,
                                    int in_len);

// EVP_EncryptUpdate does the same as |EVP_EncryptUpdate_ex|, except that no
// output size is given and thus no bounds checking is performed.
//
// Additionally, if |ctx| is an AEAD cipher, e.g. |EVP_aes_128_gcm|, and |out|
// is NULL, this function instead behaves like |EVP_CipherUpdateAAD|.
//
// WARNING: This function does not check bounds on |out|, and correctly sizing
// the output buffer is difficult. Use |EVP_EncryptUpdate_ex| or
// |EVP_CipherUpdateAAD| instead.
OPENSSL_EXPORT int EVP_EncryptUpdate(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                     int *out_len, const uint8_t *in,
                                     int in_len);

// EVP_DecryptUpdate does the same as |EVP_DecryptUpdate_ex|, except that no
// output size is given and thus no bounds checking is performed.
//
// Additionally, if |ctx| is an AEAD cipher, e.g. |EVP_aes_128_gcm|, and |out|
// is NULL, this function instead behaves like |EVP_CipherUpdateAAD|.
//
// WARNING: This function does not check bounds on out, and correctly sizing
// the output buffer is difficult. Use |EVP_DecryptUpdate_ex| or
// |EVP_CipherUpdateAAD| instead.
OPENSSL_EXPORT int EVP_DecryptUpdate(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                     int *out_len, const uint8_t *in,
                                     int in_len);

// EVP_CipherFinal calls |EVP_CipherFinal_ex|.
OPENSSL_EXPORT int EVP_CipherFinal(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                   int *out_len);

// EVP_CipherFinal_ex does the same as |EVP_CipherFinal_ex2|, except that no
// output size is given and thus no bounds checking is performed.
//
// WARNING: This function does not check bounds on out, and correctly sizing
// the output buffer is difficult. Use |EVP_CipherFinal_ex2| instead.
OPENSSL_EXPORT int EVP_CipherFinal_ex(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                      int *out_len);

// EVP_EncryptFinal calls |EVP_EncryptFinal_ex|.
OPENSSL_EXPORT int EVP_EncryptFinal(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                    int *out_len);

// EVP_EncryptFinal_ex does the same as |EVP_EncryptFinal_ex2|, except that no
// output size is given and thus no bounds checking is performed.
//
// WARNING: This function does not check bounds on out, and correctly sizing
// the output buffer is difficult. Use |EVP_EncryptFinal_ex2| instead.
OPENSSL_EXPORT int EVP_EncryptFinal_ex(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                       int *out_len);

// EVP_DecryptFinal calls |EVP_DecryptFinal_ex|.
OPENSSL_EXPORT int EVP_DecryptFinal(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                    int *out_len);

// EVP_DecryptFinal_ex does the same as |EVP_DecryptFinal_ex2|, except that no
// output size is given and thus no bounds checking is performed.
//
// WARNING: This function does not check bounds on out, and correctly sizing
// the output buffer is difficult. Use |EVP_DecryptFinal_ex2| instead.
OPENSSL_EXPORT int EVP_DecryptFinal_ex(EVP_CIPHER_CTX *ctx, uint8_t *out,
                                       int *out_len);

// EVP_Cipher historically exposed an internal implementation detail of |ctx|
// and should not be used. Use |EVP_CipherUpdate| and |EVP_CipherFinal_ex|
// instead.
//
// If |ctx|'s cipher does not have the |EVP_CIPH_FLAG_CUSTOM_CIPHER| flag, it
// encrypts or decrypts |in_len| bytes from |in| and writes the resulting
// |in_len| bytes to |out|. It returns one on success and zero on error.
// |in_len| must be a multiple of the cipher's block size, or the behavior is
// undefined.
//
// TODO(davidben): Rather than being undefined (it'll often round the length up
// and likely read past the buffer), just fail the operation.
//
// If |ctx|'s cipher has the |EVP_CIPH_FLAG_CUSTOM_CIPHER| flag, it runs in one
// of two modes: If |in| is non-NULL, it behaves like |EVP_CipherUpdate|. If
// |in| is NULL, it behaves like |EVP_CipherFinal_ex|. In both cases, it returns
// |*out_len| on success and -1 on error.
//
// WARNING: The two possible calling conventions of this function signal errors
// incompatibly. In the first, zero indicates an error. In the second, zero
// indicates success with zero bytes of output.
OPENSSL_EXPORT int EVP_Cipher(EVP_CIPHER_CTX *ctx, uint8_t *out,
                              const uint8_t *in, size_t in_len);

// EVP_add_cipher_alias does nothing and returns one.
OPENSSL_EXPORT int EVP_add_cipher_alias(const char *a, const char *b);

// EVP_get_cipherbyname returns an |EVP_CIPHER| given a human readable name in
// |name|, or NULL if the name is unknown. Note using this function links almost
// every cipher implemented by BoringSSL into the binary, not just the ones the
// caller requests. Size-conscious callers, such as client software, should not
// use this function.
OPENSSL_EXPORT const EVP_CIPHER *EVP_get_cipherbyname(const char *name);

// These AEADs are deprecated AES-GCM implementations that set
// |EVP_CIPH_FLAG_CUSTOM_CIPHER|. Use |EVP_aead_aes_128_gcm| and
// |EVP_aead_aes_256_gcm| instead.
//
// WARNING: Although these APIs allow streaming an individual AES-GCM operation,
// this is not secure. Until calling |EVP_DecryptFinal_ex|, the tag has not yet
// been checked and output released by |EVP_DecryptUpdate| is unauthenticated
// and easily manipulated by attackers. Callers must buffer the output and may
// not act on it until the entire operation is complete.
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_128_gcm(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_256_gcm(void);

// These are deprecated, 192-bit version of AES.
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_192_ecb(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_192_cbc(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_192_ctr(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_192_gcm(void);
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_192_ofb(void);

// EVP_des_ede3_ecb is an alias for |EVP_des_ede3|. Use the former instead.
OPENSSL_EXPORT const EVP_CIPHER *EVP_des_ede3_ecb(void);

// EVP_aes_128_cfb128 is only available in decrepit.
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_128_cfb128(void);

// EVP_aes_128_cfb is an alias for |EVP_aes_128_cfb128| and is only available in
// decrepit.
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_128_cfb(void);

// EVP_aes_192_cfb128 is only available in decrepit.
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_192_cfb128(void);

// EVP_aes_192_cfb is an alias for |EVP_aes_192_cfb128| and is only available in
// decrepit.
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_192_cfb(void);

// EVP_aes_256_cfb128 is only available in decrepit.
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_256_cfb128(void);

// EVP_aes_256_cfb is an alias for |EVP_aes_256_cfb128| and is only available in
// decrepit.
OPENSSL_EXPORT const EVP_CIPHER *EVP_aes_256_cfb(void);

// EVP_bf_ecb is Blowfish in ECB mode and is only available in decrepit.
OPENSSL_EXPORT const EVP_CIPHER *EVP_bf_ecb(void);

// EVP_bf_cbc is Blowfish in CBC mode and is only available in decrepit.
OPENSSL_EXPORT const EVP_CIPHER *EVP_bf_cbc(void);

// EVP_bf_cfb is Blowfish in 64-bit CFB mode and is only available in decrepit.
OPENSSL_EXPORT const EVP_CIPHER *EVP_bf_cfb(void);

// EVP_cast5_ecb is CAST5 in ECB mode and is only available in decrepit.
OPENSSL_EXPORT const EVP_CIPHER *EVP_cast5_ecb(void);

// EVP_cast5_cbc is CAST5 in CBC mode and is only available in decrepit.
OPENSSL_EXPORT const EVP_CIPHER *EVP_cast5_cbc(void);

// The following flags do nothing and are included only to make it easier to
// compile code with BoringSSL.
#define EVP_CIPHER_CTX_FLAG_WRAP_ALLOW 0

// EVP_CIPHER_CTX_set_flags does nothing.
OPENSSL_EXPORT void EVP_CIPHER_CTX_set_flags(const EVP_CIPHER_CTX *ctx,
                                             uint32_t flags);


// Private functions.

// EVP_CIPH_NO_PADDING disables padding in block ciphers.
#define EVP_CIPH_NO_PADDING 0x800

// The following are |EVP_CIPHER_CTX_ctrl| commands.
#define EVP_CTRL_INIT 0x0
#define EVP_CTRL_SET_KEY_LENGTH 0x1
#define EVP_CTRL_GET_RC2_KEY_BITS 0x2
#define EVP_CTRL_SET_RC2_KEY_BITS 0x3
#define EVP_CTRL_GET_RC5_ROUNDS 0x4
#define EVP_CTRL_SET_RC5_ROUNDS 0x5
#define EVP_CTRL_RAND_KEY 0x6
#define EVP_CTRL_PBE_PRF_NID 0x7
#define EVP_CTRL_COPY 0x8
#define EVP_CTRL_AEAD_SET_IVLEN 0x9
#define EVP_CTRL_AEAD_GET_TAG 0x10
#define EVP_CTRL_AEAD_SET_TAG 0x11
#define EVP_CTRL_AEAD_SET_IV_FIXED 0x12
#define EVP_CTRL_GCM_IV_GEN 0x13
#define EVP_CTRL_AEAD_SET_MAC_KEY 0x17
// EVP_CTRL_GCM_SET_IV_INV sets the GCM invocation field, decrypt only
#define EVP_CTRL_GCM_SET_IV_INV 0x18
#define EVP_CTRL_GET_IVLEN 0x19

// The following constants are unused.
#define EVP_GCM_TLS_FIXED_IV_LEN 4
#define EVP_GCM_TLS_EXPLICIT_IV_LEN 8
#define EVP_GCM_TLS_TAG_LEN 16

// The following are legacy aliases for AEAD |EVP_CIPHER_CTX_ctrl| values.
#define EVP_CTRL_GCM_SET_IVLEN EVP_CTRL_AEAD_SET_IVLEN
#define EVP_CTRL_GCM_GET_TAG EVP_CTRL_AEAD_GET_TAG
#define EVP_CTRL_GCM_SET_TAG EVP_CTRL_AEAD_SET_TAG
#define EVP_CTRL_GCM_SET_IV_FIXED EVP_CTRL_AEAD_SET_IV_FIXED

#define EVP_MAX_KEY_LENGTH 64
#define EVP_MAX_IV_LENGTH 16
#define EVP_MAX_BLOCK_LENGTH 32

struct evp_cipher_ctx_st {
  // cipher contains the underlying cipher for this context.
  const EVP_CIPHER *cipher;

  // app_data is a pointer to opaque, user data.
  void *app_data;      // application stuff

  // cipher_data points to the |cipher| specific state.
  void *cipher_data;

  // key_len contains the length of the key, which may differ from
  // |cipher->key_len| if the cipher can take a variable key length.
  unsigned key_len;

  // encrypt is one if encrypting and zero if decrypting.
  int encrypt;

  // flags contains the OR of zero or more |EVP_CIPH_*| flags, above.
  uint32_t flags;

  // oiv contains the original IV value.
  uint8_t oiv[EVP_MAX_IV_LENGTH];

  // iv contains the current IV value, which may have been updated.
  uint8_t iv[EVP_MAX_IV_LENGTH];

  // buf contains a partial block which is used by, for example, CTR mode to
  // store unused keystream bytes.
  uint8_t buf[EVP_MAX_BLOCK_LENGTH];

  // buf_len contains the number of bytes of a partial block contained in
  // |buf|.
  int buf_len;

  // num contains the number of bytes of |iv| which are valid for modes that
  // manage partial blocks themselves.
  unsigned num;

  // final_used is non-zero if the |final| buffer contains plaintext.
  int final_used;

  uint8_t final[EVP_MAX_BLOCK_LENGTH];  // possible final block

  // Has this structure been rendered unusable by a failure.
  int poisoned;
} /* EVP_CIPHER_CTX */;

typedef struct evp_cipher_info_st {
  const EVP_CIPHER *cipher;
  unsigned char iv[EVP_MAX_IV_LENGTH];
} EVP_CIPHER_INFO;


#if defined(__cplusplus)
}  // extern C

#if !defined(BORINGSSL_NO_CXX)
extern "C++" {

BSSL_NAMESPACE_BEGIN

BORINGSSL_MAKE_DELETER(EVP_CIPHER_CTX, EVP_CIPHER_CTX_free)

using ScopedEVP_CIPHER_CTX =
    internal::StackAllocated<EVP_CIPHER_CTX, int, EVP_CIPHER_CTX_init,
                             EVP_CIPHER_CTX_cleanup>;

BSSL_NAMESPACE_END

}  // extern C++
#endif

#endif

#define CIPHER_R_AES_KEY_SETUP_FAILED 100
#define CIPHER_R_BAD_DECRYPT 101
#define CIPHER_R_BAD_KEY_LENGTH 102
#define CIPHER_R_BUFFER_TOO_SMALL 103
#define CIPHER_R_CTRL_NOT_IMPLEMENTED 104
#define CIPHER_R_CTRL_OPERATION_NOT_IMPLEMENTED 105
#define CIPHER_R_DATA_NOT_MULTIPLE_OF_BLOCK_LENGTH 106
#define CIPHER_R_INITIALIZATION_ERROR 107
#define CIPHER_R_INPUT_NOT_INITIALIZED 108
#define CIPHER_R_INVALID_AD_SIZE 109
#define CIPHER_R_INVALID_KEY_LENGTH 110
#define CIPHER_R_INVALID_NONCE_SIZE 111
#define CIPHER_R_INVALID_OPERATION 112
#define CIPHER_R_IV_TOO_LARGE 113
#define CIPHER_R_NO_CIPHER_SET 114
#define CIPHER_R_OUTPUT_ALIASES_INPUT 115
#define CIPHER_R_TAG_TOO_LARGE 116
#define CIPHER_R_TOO_LARGE 117
#define CIPHER_R_UNSUPPORTED_AD_SIZE 118
#define CIPHER_R_UNSUPPORTED_INPUT_SIZE 119
#define CIPHER_R_UNSUPPORTED_KEY_SIZE 120
#define CIPHER_R_UNSUPPORTED_NONCE_SIZE 121
#define CIPHER_R_UNSUPPORTED_TAG_SIZE 122
#define CIPHER_R_WRONG_FINAL_BLOCK_LENGTH 123
#define CIPHER_R_NO_DIRECTION_SET 124
#define CIPHER_R_INVALID_NONCE 125

#endif  // OPENSSL_HEADER_CIPHER_H
